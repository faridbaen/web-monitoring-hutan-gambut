<?php
include "koneksi.php";
?>


<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>MONITORING HUTAN GAMBUT</title>
        <!-- Favicon-->
        <link rel="icon" type="image/x-icon" href="assets/img/MHG.png" />
        <!-- Font Awesome icons (free version)-->
        <script src="https://use.fontawesome.com/releases/v5.15.1/js/all.js" crossorigin="anonymous"></script>
        <!-- Google fonts-->
        <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css" />
        <link href="https://fonts.googleapis.com/css?family=Lato:400,700,400italic,700italic" rel="stylesheet" type="text/css" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="assets/css/bootstrap.min.css" rel="stylesheet">
  
        <link href="css/styles.css" rel="stylesheet" />
    </head>
    <body id="page-top">
        <!-- Navigation-->
        <nav class="navbar navbar-expand-lg bg-secondary text-uppercase fixed-top" id="mainNav">
            <div class="container">
                <a class="navbar-brand " href="index.php">MONITORING HUTAN GAMBUT</a>
                <button class="navbar-toggler navbar-toggler-right text-uppercase font-weight-bold bg-primary text-white rounded" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                    Menu
                    <i class="fas fa-bars"></i>
                </button>
                <div class="collapse navbar-collapse" id="navbarResponsive">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item mx-0 mx-lg-1"><a class="nav-link py-3 px-0 px-lg-3 " href="index.php">home</a></li>
                    </ul>
                 </li>
                
                </div>
              </div>
            </nav>
            <br><br>

<!-- Begin page content -->
<section class="page-section bg-primary text-white mb-0" >
           
<div class="container">
  <div class="panel panel-primary">
    <div class="panel-heading">
        <h3 class="panel-title"><center>Logger</h3>
    </div>
    
    <?php
     if(isset($_GET['sdate']) || isset($_GET['edate']))
     {
       
       $sdate = $_GET['sdate'];
       $edate = $_GET['edate'];	
       $sqlAdmin = mysqli_query($konek, "SELECT id,waktu,temperature,humidity FROM dht11 WHERE waktu BETWEEN ' $sdate ' AND ' $edate ' ORDER BY ID DESC LIMIT 0,100");
     }
     else
     {
       $sqlAdmin = mysqli_query($konek, "SELECT id,waktu,temperature,humidity FROM dht11 ORDER BY ID DESC LIMIT 0,100");
     }
     ?>
 
     <div class="panel-body">
       <form class="form-horizontal" method="GET">  
         <div class="form-group">
           <label class="col-md-2style=" font-size:30px; font-weigh: bold;>Dari tanggal</label>   
           <div class="col-md-2">
             <input type="date" name="sdate" class="form-control" value="<?php echo $sdate; ?>" required>
           </div>
         </div>
         <div class="form-group">
           <label class="col-md-2">sampai tanggal</label>   
           <div class="col-md-2">
             <input type="date" name="edate" class="form-control" value="<?php echo $edate; ?>" required>
           </div>
         </div>
         <div class="form-group">
           <label class="col-md-2"></label>   
           <div class="col-md-8">
             <input type="submit" class="btn btn-primary" value="Filter">
             <a href="goal.php"  class='btn btn-warning btn-sm'>Reset</a>
           </div>
         </div>
       </form>
 
       <table class="table table-bordered table-striped">
         <thead>
           <tr >
             <th class='text-center'>ID</th>
             <th class='text-center'>Tanggal</th>
             <th class='text-center'> Temperature (C)</th>
             <th class='text-center'>humidity (%)</th>    
           </tr>
         </thead>
         <tbody>
           <?php
             
           while($data=mysqli_fetch_array($sqlAdmin))
           {
             echo "<tr >
             <td><center>$data[id]</td>
             <td><center>$data[waktu]</center></td> 
             <td><center>$data[temperature]</td>
             <td><center>$data[humidity]</td>              
             </tr>";
           }
           ?>
        </tbody>
      </table> 
    </div>
    </div>
  </div>
</div>
</section>
<?php include "footer.php"; ?>