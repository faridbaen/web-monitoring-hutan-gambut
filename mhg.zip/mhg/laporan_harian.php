<?php
// memanggil library FPDF
require('fpdf.php');
// intance object dan memberikan pengaturan halaman PDF
$pdf = new FPDF('P','mm','A4');
// membuat halaman baru
$pdf->AddPage();
// setting jenis font yang akan digunakan
$pdf->SetFont('Arial','B',16);
// mencetak string 
$pdf->Cell(190,7,'LAPORAN HARIAN ',0,1,'C');
$pdf->SetFont('Arial','B',12);
$pdf->Cell(190,7,'MONITORING HUTAN GAMBUT' ,0,1,'C');

$pdf->SetFont('Arial','B',12);
$pdf->Cell(190,7,
 date("l, d-m-y") ,0,1,'C');

// Memberikan space kebawah agar tidak terlalu rapat
$pdf->Cell(10,7,'',0,1);

$pdf->SetFont('Arial','B',10);
$pdf->Cell(20,6,'id',1,0);
$pdf->Cell(85,6,'waktu',1,0);
$pdf->Cell(27,6,'temperature',1,0);
$pdf->Cell(25,6,'humidity',1,1);

$pdf->SetFont('Arial','',10);

include 'koneksi.php';
$dht11 = mysqli_query($konek, ' SELECT * FROM dht11 ORDER BY ID DESC');
while ($row = mysqli_fetch_array($dht11)){
    $pdf->Cell(20,6,$row['id'],1,0);
    $pdf->Cell(85,6,$row['waktu'],1,0);
    $pdf->Cell(27,6,$row['temperature'],1,0);
    $pdf->Cell(25,6,$row['humidity'],1,1); 
}

$pdf->Output();
?>