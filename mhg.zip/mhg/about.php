<?php include "header.php";?>

<!-- Begin page content -->
 <div class="container">
    <div class="panel panel-primary">
      <div class="panel-heading">
         <h3 class="panel-title">About Us</h3>
      </div>
      <div class="panel-body">
      <style>
* {
  box-sizing: border-box;
}
.menu {
  float:left;
  width:20%;
  text-align:left;
}
.menu a {
  background-color:#e5e5e5;
  padding:38px;
  margin-top:7px;
  display:block;
  width:100%;
  color:black;
}
.main {
  float:left;
  width:60%;
  padding:0 40px;
}
.right {
  background-color:#e5e5e5;
  float:left;
  width:30%;
  padding:15px;
  margin-top:10px;
  text-align:center;
}

@media only screen and (max-width:620px) {
  /* For mobile phones: */
  .menu, .main, .right {
    width:100%;
  }
}
</style>
</head>
<body style="font-family:Verdana;color:#aaaaaa;">



<div style="overflow:auto">
  <div class="menu">  
  </div>

  <div class="main">
    <h2>Sistem Monitoring Biogas</h2>
    <p>Biogas merupakan salah satu energi terbarukan, penelitian untuk mengembangkan biogas terus dilakukan oleh karena itu hadirnya website ini berfungsi sebagai sistem monitoring untuk mengetahui kadar gas metana dan karbondioksida berbasis website. Sistem Monitoring ini masih dalam tahap penelitian.</p>
  </div>

  <div class="right">
    <h2>Contact Us</h2>
    <p>M Taufiqi Arrais<br>taufiqiarrais24@gmail.com<br>Winaldha Erza N.H<br>erzahafizah@gmail.com.</p>
  </div>
</div>




      </div>
    </div>
</div>

    
<?php include "footer.php"; ?>

