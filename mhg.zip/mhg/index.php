<?php include "header.php"; ?>
        <!-- Masthead-->
        <header class="masthead bg-primary text-white text-center">
            <div class="container d-flex align-items-center flex-column">
                <!-- Masthead Avatar Image-->
                <img class="masthead-avatar mb-5" src="assets/img/MHG.png" alt="" />
                <!-- Masthead Heading-->
                <h1 class="masthead-heading text-uppercase mb-0">FISIKA</h1>
                <!-- Icon Divider-->
                <div class="divider-custom divider-light">
                    <div class="divider-custom-line"></div>
                    <div class="divider-custom-icon"><i class="fas fa-star"></i></div>
                    <div class="divider-custom-line"></div>
                </div>
                <!-- Masthead Subheading-->
                <p class="masthead-subheading font-weight-light mb-0">Institut Teknologi Sumatera</p>
            </div>
        </header>
        <!-- Portfolio Section-->
        <section class="page-section portfolio" id="portfolio">
            <div class="container">
                <!-- Portfolio Section Heading-->
                <h2 class="page-section-heading text-center text-uppercase text-secondary mb-0">Grafik</h2>
                <!-- Icon Divider-->
                <div class="divider-custom">
                    <div class="divider-custom-line"></div>
                    <div class="divider-custom-icon"><i class="fas fa-chart-line"></i></div>
                    <div class="divider-custom-line"></div>
                </div>
                <!-- Portfolio Grid Items-->
                <script src="jquery-latest.js"></script> 
                    <script>
                    var refreshId = setInterval(function()
                    {
                        $('#responsecontainer').load('data.php');
                    }, 1000);
                    </script>
                        
                    <!-- Begin page content -->
                    <div class="container">

                    <script type="text/javascript" src="assets/js/jquery-3.4.0.min.js"></script>
                    <script type="text/javascript" src="assets/js/mdb.min.js"></script>
                    
                    <div id="responsecontainer">
                        
                    </div>	
                  
                                   
                            </section>
        <!-- About Section-->
        <section class="page-section bg-primary text-white mb-0" id="about">
            <div class="container">
                <!-- About Section Heading-->
                <h2 class="page-section-heading text-center text-uppercase text-white">About</h2>
                <!-- Icon Divider-->
                <div class="divider-custom divider-light">
                    <div class="divider-custom-line"></div>
                    <div class="divider-custom-icon"><i class="fas fa-seedling"></i></div>
                    <div class="divider-custom-line"></div>
                </div>
                <!-- About Section Content-->
                <div class="row">
                    <div class="col-lg-4 ml-auto"><p class="lead">Hasil penelitian menunjukkan bahwa luas lahan gambut Indonesia berdasarkan hasil kombinasi analisis landsat TM dan data survei tanah sampai dengan tahun 2011 adalah sekitar 14,9 juta ha, tersebar di Sumatera, Kalimantan dan Papua. Luas ini turun drastis dari perkiraan semula seluas 20,6 juta ha. Lahan gambut di Pulau Sumatera dan Kalimantan berkurang sekitar 700 ribu sampai 1 juta ha. Sedangkan di Papua luasnya berkurang sekitar 4,4 juta ha dari 8 juta ha karena estimasi luasan yang terdahulu hanya didasarkan hasil analisis citra satelit dan sedikit data verifikasi lapang (ground truth).</p></div>
                    <div class="col-lg-4 mr-auto"><p class="lead">You can create your own custom avatar for the masthead, change the icon in the dividers, and add your email address to the contact form to make it fully functional!</p></div>
                </div>
               
            </div>
        </section>
        <!-- Contact Section-->
    
            
        <?php include "footer.php"; ?>
       