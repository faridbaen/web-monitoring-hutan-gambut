<?php
include "koneksi.php";
$sql = mysqli_query($konek, "SELECT * FROM dht11 ORDER BY id DESC ");
            $temp = mysqli_fetch_array($sql);
            $suhu = $temp['temperature'];?>
<!DOCTYPE html>
<html lang="en-US">
<head>

  <title>grafik suhu</title>
  <meta charset="utf-8">
 <script src="assets/justgage/raphael-2.1.4.min.js"></script>
<script src="assets/justgage/justgage.js"></script>
 </head>
<body>

<div id="suhu" class="200x160px"></div>
<script>
  var g = new JustGage({
    id: "suhu",
    value: <?php echo $suhu ?>,
    min: 0,
    max: 100,
    title: "temperature"
  });
</script>
</body>
</html>