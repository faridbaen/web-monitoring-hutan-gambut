<?php
include "koneksi.php";
$sql = mysqli_query($konek, "SELECT * FROM dht11 ORDER BY id DESC ");
            $temp = mysqli_fetch_array($sql);
            $humi = $temp['humidity'];?>
<!DOCTYPE html>
<html lang="en-US">
<head>

  <title>grafik gauge</title>
  <meta charset="utf-8">
 <script src="assets/justgage/raphael-2.1.4.min.js"></script>
<script src="assets/justgage/justgage.js"></script>
 </head>
<body>

<div id="gauge" class="200x160px"></div>
<script>
 var g = new JustGage({
        id: 'gauge',
        value: <?php echo $humi ?>,
        min: 0,
        max: 100,
        reverse: true,
        title: "humidity",
        gaugeWidthScale: 1,
        customSectors: [{
          color: '#00ff00',
          lo: 50,
          hi: 100
        }, {
          color: '#ff0000',
          lo: 0,
          hi: 50
        }],
        counter: true
      });

</script>
</body>
</html>