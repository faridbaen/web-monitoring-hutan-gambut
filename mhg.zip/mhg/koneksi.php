<?php
$host ='localhost';
$user ='root';
$pas ='';
$database='nodemcu_ldr';

$konek = mysqli_connect($host,$user,$pas,$database);

if (!$konek)
{
	echo "koneksi ke MYSQL gagal....";
}
?>